package version1;

import java.io.*;
import java.net.URISyntaxException;
import java.nio.file.Path;
import java.nio.charset.Charset;
import java.nio.file.*;
import java.util.*;
import java.util.stream.*;

public class CsvFix {
	private static String fileName;
	private static ArrayList <ArrayList <String>> arraysArray = new ArrayList<ArrayList <String>>();
	private static ArrayList <ArrayList <String>> arraySortBySignal = new ArrayList<ArrayList <String>>();
	private static ArrayList <ArrayList <String>> arraySortByTime = new ArrayList<ArrayList <String>>();
	private static File folder = new File("C:/Users/InnaPC/Desktop/munhe/Lenovo");
	private static File[] files = folder.listFiles();

	public static void readFile (String fileName){
		
		//taken from first year -ex4
		// try read from the file
		try {
			FileReader fr = new FileReader(fileName);
			BufferedReader br = new BufferedReader(fr);
			String str;

			str = br.readLine();
			List <String> firstLine= Arrays.asList(str.split(","));
			String id = firstLine.get(4);

			str = br.readLine();
			str = br.readLine();
			while(str != null){
				List <String> tempfilesArray= Arrays.asList(str.split(","));
				ArrayList <String> temp = new ArrayList<String>(tempfilesArray);
				temp.add(id);
				temp= organizeCsv(temp);
				arraysArray.add(temp);
				str = br.readLine();
			}
			br.close();
			fr.close();
		}
		catch(IOException ex) {
			System.out.print("Error reading file\n" + ex);
			System.exit(2);
		}
	}
	
	public static void writeFile (ArrayList<ArrayList <String>> arr){
		
		try{
		FileWriter writeCsv = new FileWriter("C:/Users/InnaPC/Desktop/munhe/gmon.csv");

		for(int i=0; i<arr.size(); i++){
			String row = arr.get(i).stream().collect(Collectors.joining(","));
			writeCsv.write(row);
			writeCsv.write("\n");
		}
		writeCsv.close();
	}
		catch(IOException ex) {
			System.out.print("Error writing file\n" + ex);
			System.exit(2);
		}
		
	}
	
	//this function organizes Csv by this order: 
	//time, id, Lat, Lon, Alt, SSID, MAC, Frequncy, signal 
	private static ArrayList<String> organizeCsv(ArrayList<String> arr){
		ArrayList <String> temp = new ArrayList<String>();
		
		temp.add(arr.get(3));
		temp.add(arr.get(11));
		temp.add(arr.get(6));
		temp.add(arr.get(7));
		temp.add(arr.get(8));
		temp.add(arr.get(1));
		temp.add(arr.get(0));
		temp.add(arr.get(4));
		temp.add(arr.get(5));
		return temp;
	}
	
	public static void rowWrite(){
		ArrayList <rowMeasurement> st = new ArrayList <rowMeasurement>();
		st.addAll(st);
		//		st.addAll(new ArrayList<rowMeasurement>());
		//Collections.addAll();
//("row", "time", "id", "lat", "lon", "alt", "ssid", "mac", "frequncy", "signal");
	//	CsvFix.writeFile(st);
	}

	/**
	 * 
	 * @param arr
	 * @return
	 */
	//���� ROWMESS--> ������ FINALMESS
	//ROW =  10, FINAL = 46
	public static ArrayList<ArrayList<String>> sortArrayByTime(ArrayList<rowMeasurement> arr){
		
		//arraySortByTime = arr;
		Collections.sort(arraySortByTime, new timeComp()); //sorts the array by time
		ArrayList <ArrayList<String>> result = new ArrayList<>();
		int count = 0;
		int k =1; 
		for (int i = 0; i < arraySortByTime.size()-1; i++) {
			count=0;
			ArrayList <String> temp = new ArrayList<String>();
			while(arraySortByTime.get(i).get(0).equals(arraySortByTime.get(k).get(0)) && i < arraySortByTime.size() && count <11){
				temp.addAll(arraySortByTime.get(i));
				count++;
				k++;
			}
			//���� ����� ��� �� �� ����� ������ ����� ��� ��� ������ �� ����� ������� �� ����
			//���� ������ ��� ����� �6 ����� ������� �����.
			result.add(temp);
			//Collections.sort(arraySortByTime, new signalComp());	
		}
		
		return result;
	}

	public static void main(String[] args) throws URISyntaxException,IOException {
		for(int i=0; i<files.length; i++){
			fileName = files[i].getPath();
			readFile(fileName);
		}
		writeFile(sortArrayByTime(arraysArray));
		for (int i = 0; i <100; i++) 
			System.out.println(arraysArray.get(i));
	}
}




package munhe;

public class measurement {
	private static String Time;
	private static String ID;
	private static String LAT;
	private static String LON;
	private static String ALT;
	private static String SSID;
	private static String MAC;
	private static String Frequncy;
	private static String SIGNAL;
	
	public static void addAll(rowMeasurement row, String time,String id,String lat,String lon,String alt,String ssid,String mac,String frequncy, String signal){
		Time = time;
		ID = id;
		LAT = lat;
		LON = lon;
		ALT = alt;
		SSID = ssid;
		SIGNAL = signal;
		MAC = mac;
		Frequncy = frequncy;
		
	}
	public String getTime() {
		return Time;
	}
	public String getID() {
		return ID;
	}
	public String getLAT() {
		return LAT;
	}
	public String getLON() {
		return LON;
	}
	public String getALT() {
		return ALT;
	}
	public String getSSID() {
		return SSID;
	}
	public String getSIGNAL() {
		return SIGNAL;
	}
	public String getMAC() {
		return MAC;
	}
	public String getFrequncy() {
		return Frequncy;
	}
	
}

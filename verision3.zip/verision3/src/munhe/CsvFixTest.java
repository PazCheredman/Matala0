package munhe;

import static org.junit.Assert.*;

import java.net.URISyntaxException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import org.junit.Test;

public class CsvFixTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

	@Test
	public static void test1line(){
		ArrayList <ArrayList <String>> st = new ArrayList <ArrayList <String>>();
		st.add(new ArrayList<String>());
		st.get(0).add("hello");
		Collections.addAll(st.get(0), "time", "id", "vt", "ddd", "ffff", "ddd", "ssss", "ccc", "fmfn", "xxxx");
		CsvFix.writeFile(st);
	}

	@Test
	public static void test2line(){
		
			ArrayList <ArrayList <String>> st = new ArrayList <ArrayList <String>>();

			st.add(new ArrayList<String>());
			st.get(0).add("hello");
			Collections.addAll(st.get(0), "time", "id", "vt", "ddd");
			st.add(new ArrayList<String>());
			st.get(1).add("hello");
			Collections.addAll(st.get(1),"ffff", "ddd", "ssss", "ccc", "fmfn", "xxxx");
			CsvFix.writeFile(st);
		


	}
}

package munhe;

public class FinalMeasurement {

	private String Time;
	private String ID;
	private String LAT;
	private String LON;
	private String ALT;
	
	private String SSID;
	private String SIGNAL;
	private String MAC;
	private String Frequncy;
	
}



import java.util.Date;
import java.util.ArrayList;
import java.util.Comparator;

public class row {
	int signal;
	String name;
	Date time;

	public row(int signal, String name, Date time){
		super();
		this.signal = signal;
		this.name = name;
		this.time = time;
	}



	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<row> row = new ArrayList<row>();
		row.add(new row(1, "a", new Date()));
		row.add(new row(2, "a", new Date()));
		row.add(new row(3, "a", new Date()));
		Comparator com = new Comparator<row>(){

			@Override
			public int compare(row arg0, row arg1){
				return arg0.signal-arg1.signal;
			}
		};
		row.sort(com);
	}

}

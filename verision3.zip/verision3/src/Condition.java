import munhe.Csv;

public interface Condition {
	boolean test(String s);

}
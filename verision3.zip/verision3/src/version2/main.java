package version2;

import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.Arrays;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		rowMeasurement.addAll("12","he", "124","123","herfw", "12", "56", "-999", "919");
		System.out.println(rowMeasurement.getTime());
		
		
		//ArrayList <rowMeasurement> st = new ArrayList <rowMeasurement>();
		/*rowMeasurement time= new rowMeasurement();
		rowMeasurement id= new rowMeasurement();

		time.setTime("12:44");
		id.setID("myid");
		st.add(time);
		st.add(id);
		System.out.print(st.get(0).getTime()+", "+ st.get(0).getID());

		for(int i=1; i<10 ; i++){
		time.setTime("12:44");
		id.setID("myid");
		
		st.add(time);
		st.add(id);
		System.out.print(", "+st.get(i).getTime()+", "+ st.get(i).getID());

	}*/
		
		
	/*	rowMeasurement id= new rowMeasurement();
		rowMeasurement lat= new rowMeasurement();
		rowMeasurement lon= new rowMeasurement();
		rowMeasurement alt= new rowMeasurement();
		rowMeasurement ssid= new rowMeasurement();
		rowMeasurement mac= new rowMeasurement();
		rowMeasurement frequncy= new rowMeasurement();
		rowMeasurement signal= new rowMeasurement();
		
	
		//st.add(time);
		
		st.add(id);
		st.add(lat);
		st.add(lon);
		st.add(alt);
		st.add(ssid);
		st.add(mac);
		st.add(frequncy);
		st.add(signal);
		System.out.print(st);*/
	} 

}

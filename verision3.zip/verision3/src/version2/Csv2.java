package version2;

import java.io.*;

import java.net.URISyntaxException;
import java.nio.file.Path;
import java.nio.charset.Charset;
import java.nio.file.*;
import java.util.*;
import java.util.stream.*;

import version2.arrayOfArrayRow;
import version2.arrayRowMeasurement;

public class Csv2 {
	private static String fileName;
	private static ArrayList <arrayOfArrayRow> arraysArray = new ArrayList<arrayOfArrayRow>();
	private static ArrayList <arrayRowMeasurement> arraySortBySignal = new ArrayList<arrayRowMeasurement>();
	private static ArrayList <arrayRowMeasurement> arraySortByTime = new ArrayList<arrayRowMeasurement>();
	private static File folder = new File("C:/Users/InnaPC/Desktop/New folder/Lenovo");
	private static File[] files = folder.listFiles();

	public static void readFile (String fileName){
		
		//taken from first year -ex4
		// try read from the file
		try {
			FileReader fr = new FileReader(fileName);
			BufferedReader br = new BufferedReader(fr);
			String str;

			str = br.readLine();
			List <String> firstLine= Arrays.asList(str.split(","));
			String id = firstLine.get(4);

			str = br.readLine();
			str = br.readLine();
			while(str != null){
				List <String> tempfilesArray= Arrays.asList(str.split(","));
				ArrayList <String> temp = new ArrayList<String>(tempfilesArray);
				temp.add(id);
				temp= organizeCsv(temp);
				arraysArray.add(temp);
				str = br.readLine();
			}
			br.close();
			fr.close();
		}
		catch(IOException ex) {
			System.out.print("Error reading file\n" + ex);
			System.exit(2);
		}
	}
	
	public static void writeFile (ArrayList<arrayRowMeasurement> arr){
		
		try{
		FileWriter writeCsv = new FileWriter("C:/Users/InnaPC/Desktop/New folder/Lenovo/gmon.csv");
/*		FileReader fr = new FileReader(fileName);
		BufferedReader br = new BufferedReader(fr);
		String str;
		str = br.readLine();
		List <String> firstLine= Arrays.asList(str.split(","));

		List <String> tempfilesArray= Arrays.asList(str.split(","));
		ArrayList <String> temp = new ArrayList<String>(tempfilesArray);
*/		
		/*for(int i=0; i<arraysArray.size(); i++){
			arr.add(str)
		}*/

		ArrayList <arrayOfArrayRow> temp = new ArrayList<>();
		 temp.get(0).stream().collect(Collectors.joining(","));
		 
	/*	temp.add("Time");
		temp.add("ID");
		temp.add("Lat");
		temp.add("Lon");
		temp.add("Alt");

		String Time = arr.get(0).stream().collect(Collectors.joining(","));
		String ID = arr.get(1).stream().collect(Collectors.joining(","));
		String Lat = arr.get(2).stream().collect(Collectors.joining(","));
		String Lon = arr.get(3).stream().collect(Collectors.joining(","));
		String Alt = arr.get(4).stream().collect(Collectors.joining(","));
	
		String SSID = arr.get(5).stream().collect(Collectors.joining(","));
		String MAC = arr.get(6).stream().collect(Collectors.joining(","));
		String Frequncy = arr.get(7).stream().collect(Collectors.joining(","));
		String Signal = arr.get(8).stream().collect(Collectors.joining(","));*/
	/*	
		writeCsv.write(Time);
		writeCsv.write("\n");
		writeCsv.write(ID);
		writeCsv.write("\n");
		writeCsv.write(Lat);
		writeCsv.write("\n");
		writeCsv.write(Lon);
		writeCsv.write("\n");
		writeCsv.write(Alt);
		writeCsv.write("\n");
		writeCsv.write(SSID);
		writeCsv.write("\n");
		writeCsv.write(MAC);
		writeCsv.write("\n");
		writeCsv.write(Frequncy);
		writeCsv.write("\n");
		writeCsv.write(Signal);
		writeCsv.close();*/
	}
		catch(IOException ex) {
			System.out.print("Error writing file\n" + ex);
			System.exit(2);
		}
		
	}
	
	
	
	
	
	//this function organizes Csv by this order: 
	//time, id, Lat, Lon, Alt, SSID, MAC, Frequncy, signal 
	private static ArrayList<String> organizeCsv(ArrayList<String> arr){
		ArrayList <String> temp = new ArrayList<String>();
		
		temp.add(arr.get(3));
		temp.add(arr.get(11));
		temp.add(arr.get(6));
		temp.add(arr.get(7));
		temp.add(arr.get(8));
		temp.add(arr.get(1));
		temp.add(arr.get(0));
		temp.add(arr.get(4));
		temp.add(arr.get(5));
		return temp;
	}

	private static void sortArray(ArrayList<ArrayList<String>> arr){
		arraySortByTime = arr;
		Collections.sort(arraySortByTime, new timeComp());
		ArrayList <String> temp = new ArrayList<String>();

		int count = 0;
		int k =1; 
		for (int i = 0; i < arraySortByTime.size()-1; i++) {
			count=0;
			while(arraySortByTime.get(i) == arraySortByTime.get(k) && i < arraySortByTime.size() && count <11){
				temp.addAll(arraySortByTime.get(i));
				count++;
				k++;
			}
			Collections.sort(arraySortByTime, new signalComp());	
		}
		writeFile(arraySortByTime);
	}

	public static void main(String[] args) throws URISyntaxException,IOException {
		for(int i=0; i<files.length; i++){
			fileName = files[i].getPath();
			readFile(fileName);
		}
		sortArray(arraysArray);
		for (int i = 0; i <100; i++) 
			System.out.println(arraysArray.get(i));
	}
}




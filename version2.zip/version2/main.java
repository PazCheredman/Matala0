package version2;

import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.Arrays;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	arrayOfArrayRow ar= new arrayOfArrayRow();
	ar.addAll("12","222", "ww", "lon", "alt", "ssid", "mac", "frequncy", "signal");
	ar.toString();
		
		/*
		ArrayList <rowMeasurement> st = new ArrayList <rowMeasurement>();
		rowMeasurement time= new rowMeasurement();
		rowMeasurement id= new rowMeasurement();

		time.setTime("12:44");
		id.setID("myid");
		st.add(time);
		st.add(id);
		System.out.print(st.get(0).getTime()+", "+ st.get(0).getID());

		for(int i=1; i<10 ; i++){
		time.setTime("12:44");
		id.setID("myid");
		
		st.add(time);
		st.add(id);
		System.out.print(", "+st.get(i).getTime()+", "+ st.get(i).getID());

	}
		*/
		/*
		rowMeasurement id= new rowMeasurement();
		rowMeasurement lat= new rowMeasurement();
		rowMeasurement lon= new rowMeasurement();
		rowMeasurement alt= new rowMeasurement();
		rowMeasurement ssid= new rowMeasurement();
		rowMeasurement mac= new rowMeasurement();
		rowMeasurement frequncy= new rowMeasurement();
		rowMeasurement signal= new rowMeasurement();
		
	*/
	//	st.add(time);
		/*
		st.add(id);
		st.add(lat);
		st.add(lon);
		st.add(alt);
		st.add(ssid);
		st.add(mac);
		st.add(frequncy);
		st.add(signal);
	*/
	} 

}

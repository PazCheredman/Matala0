package version14;

public class ErrorInInputEception extends Exception {

}

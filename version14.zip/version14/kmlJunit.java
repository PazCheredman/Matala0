package version14;

import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Test;

public class kmlJunit {

	@Test
	public void readCsvTest() throws IOException {
		/*testKml km = new testKml();
		km.readCsvFile("C:\\Users\\InnaPC\\Desktop\\munhe\\gmon\\gmon.csv", "C:\\Users\\InnaPC\\Desktop\\munhe\\gmon");
		km.changeByFilter("id");*/
		fail("Not yet implemented");
	}

}

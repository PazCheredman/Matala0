package version14;

public class Algo2Row {

	double pi;
	int index;

	public Algo2Row(double pi, int index){
		this.pi = pi;
		this.index = index;
	}

	public double getPi() {
		return pi;
	}

	public int getIndex() {
		return index;
	}

}



package version14;

import static org.junit.Assert.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

public class algo3Junit {

	@Test
	public void algorithem3Test() throws IOException {
		/*Algorithm3 al = new Algorithm3();
		al.searchByID("jhon:22355");
		al.searchByTime("2017-10-16");
		al.searchByRadious(32.2222, 34.1111, 35, 0.1);*/
		fail("Not yet implemented");
	}

}

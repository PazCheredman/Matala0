package version14;

import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Test;

public class algo1Junit {

	@Test
	public void algorithem1Test() throws IOException {
		/*Algorithm1 al = new Algorithm1();
		al.algorithem1("C:\\Users\\InnaPC\\Desktop\\munhe\\gmon\\gmon.csv");*/
		fail("Not yet implemented");
	}

}

package version14;

public class searchByRadious {
	private double LAT,LON,ALT;
	
	public void search(double lat, double lon, double alt, double rad){
		MacSignalContainer msc = new MacSignalContainer(filename);
		msc.MacFind(mac);
	}
	
}

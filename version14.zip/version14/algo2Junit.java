package version14;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

public class algo2Junit{

	@Test
	public void algorithem2Test() {
		/*List<String> macs = new ArrayList<>();
		List<Double> signals = new ArrayList<>();
		macs.add("22");
		macs.add("22:55");
		macs.add("22:655:877");
		macs.add("22:123:789:dd545");
		signals.add(80.0);
		signals.add(82.2);
		signals.add(90.2);
		signals.add(55.1);
		
		outputTable data =new outputTable();
		data.read("C:\\Users\\InnaPC\\Desktop\\munhe\\runCheck\\_comb_all_BM2_.csv", false);
		Algorithm2 al = new Algorithm2();
		al.algorithem2(data, macs, signals);*/
		
		fail("Not yet implemented");
	}

}

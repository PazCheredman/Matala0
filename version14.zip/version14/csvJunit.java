package version14;

import static org.junit.Assert.*;

import java.io.IOException;
import java.util.List;

import org.junit.Test;

import version6.outputRow;
import version6.outputTable;
import version6.readFolder;
import version6.table;



public class csvJunit {
	
	private table inTab;
	private outputTable outTab;
	

	@Test
	public void readCsvTest() throws IOException {
		/*csv cs = new csv();
		cs.read();
		cs.process();
		cs.write();*/
			fail("Not yet implemented");
	}
	

}

package version6;
import javax.xml.*;
import java.io.File;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.File;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

@XmlRootElement(name="Placemark")
public class Placemark {
	
	private String name; 
	private String description;
	private Point point;
	
	
	public Point getPoint() {
		return point;
	}
	@XmlElement(name="point")
	public void setPoint(Point point) {
		this.point = point;
	}
	public String getName() {
		return name;
	}
	@XmlElement(name="name")
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	@XmlElement(name="description")
	public void setDescription(String description) {
		this.description = description;
	}

	
	
}

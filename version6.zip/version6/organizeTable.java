package version6;

public class organizeTable {
	
	//class not used at the end!! 
	
	
	private table tables;
	
	public organizeTable(table tabl){
		tables=tabl;
	}
	
	
}

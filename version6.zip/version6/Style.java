package version6;

public class Style {

	private String id="red";
	private String IconStyle;
	
	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	public String getIconStyle() {
		return IconStyle;
	}
	public void setIconStyle(String iconStyle) {
		IconStyle = iconStyle;
	}
	
	

}

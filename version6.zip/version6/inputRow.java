package version6;

import java.util.ArrayList;
import java.util.List;

public class inputRow {

	
	//class not used at the end ! 
	
	private List<String> input;
	
	
	public inputRow(){
		input = new ArrayList<String>();
	}
	
	public void set(String st){
		
	}
}

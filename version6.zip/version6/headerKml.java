package version6;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="kml")
public class headerKml {
	
	private String id="red";
	private String xmlns="http://www.opengis.net/kml/2.2"; 
	private PlacemarkList pl= new PlacemarkList();

	public String getStyle() {
		return id;
	}

	@XmlAttribute(name="id")
	public void setStyle(String style) {
		id = style;
	}

	
	public String getXmlns() {
		return xmlns;
	}

	@XmlAttribute(name="xmlns")
	public void setXmlns(String xmlns) {
		this.xmlns = xmlns;
	}

	
	public PlacemarkList getPl() {
		return pl;
	}
	
	@XmlElement(name="Folder")
	public void setPl(PlacemarkList pl) {
		this.pl = pl;
	}
	
	
	
}

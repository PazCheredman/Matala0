package version6;

import java.io.File;
import java.io.IOException;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import java.io.File;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

public class kml {

	public static void main(String [] args) throws IOException{


		headerKml hk= new headerKml();
		
		Placemark pc= new Placemark();
		pc.setName("if");
		pc.setDescription("233");
		Point p= new Point();
		p.setCoordinates("3.4, 22.0");
		pc.setPoint(p);
		PlacemarkList pcl= hk.getPl();
		pcl.add(pc);
		Placemark p1= new Placemark();
		p1.setDescription("22");
		p1.setName("555jf");
		Point p2= new Point();
		p2.setCoordinates("lat,lon");
		p1.setPoint(p2);
		pcl.add(p1);
		
		
		
		try {

			File file = new File("C:\\Users\\Paz Cheredman\\Desktop\\munchex0\\27.10\\kml.xml");
			JAXBContext jaxbContext = JAXBContext.newInstance(headerKml.class);
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

			// output pretty printed
			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

			jaxbMarshaller.marshal(hk, file);
			jaxbMarshaller.marshal(hk, System.out);

		} catch (JAXBException e) {
			e.printStackTrace();
		}




	}


}
